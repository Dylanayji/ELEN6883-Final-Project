import requests
import pandas as pd
import json
from datetime import datetime
import time
import matplotlib.pyplot as plt
import seaborn as sns
from tqdm import tqdm
import os
from web3 import Web3

# ----- Configuration -----
# API endpoints and keys
API_ENDPOINT = "https://api.studio.thegraph.com/query/111194/nft-trading-analysis/version/latest"
INFURA_KEY = "dfea7c97a1254b9d8e742c8d212e5ca1"  # Replace with your Infura API key
ETHERSCAN_KEY = "WVHKCRZKBCJY35AT4QP7Y9386B18Q864QD"  # Replace with your Etherscan API key

# Seaport contract address
SEAPORT_ADDRESS = "0x00000000000000ADc04C56Bf30aC9d3c0aAF14dC"

# Known NFT collections mapping
NFT_COLLECTIONS = {
    "0xbc4ca0eda7647a8ab7c2061c2e118a18a936f13d": "Bored Ape Yacht Club",
    "0xb47e3cd837ddf8e4c57f05d70ab865de6e193bbb": "CryptoPunks",
    "0x60e4d786628fea6478f785a6d7e704777c86a7c6": "Mutant Ape Yacht Club",
    "0x34d85c9cdeb23fa97cb08333b511ac86e1c4e258": "Otherdeed for Otherside",
    "0x23581767a106ae21c074b2276d25e5c3e136a68b": "Moonbirds",
    "0x8a90cab2b38dba80c64b7734e58ee1db38b8992e": "Doodles",
    "0xed5af388653567af2f388e6224dc7c4b3241c544": "Azuki", 
    "0x49cf6f5d44e70224e2e23fdcdd2c053f30ada28b": "CloneX",
    "0x7bd29408f11d2bfc23c34f18275bbf23bb716bc7": "Meebits",
    "0x306b1ea3ecdf94ab739f1910bbda052ed4a9f949": "Art Blocks",
}

# Simplified Seaport ABI, only including OrderFulfilled event
SEAPORT_ABI = '''
[
  {
    "anonymous": false,
    "inputs": [
      {
        "indexed": false,
        "internalType": "bytes32",
        "name": "orderHash",
        "type": "bytes32"
      },
      {
        "indexed": true,
        "internalType": "address",
        "name": "offerer",
        "type": "address"
      },
      {
        "indexed": true,
        "internalType": "address",
        "name": "zone",
        "type": "address"
      },
      {
        "indexed": false,
        "internalType": "address",
        "name": "recipient",
        "type": "address"
      },
      {
        "components": [
          {
            "internalType": "enum ItemType",
            "name": "itemType",
            "type": "uint8"
          },
          {
            "internalType": "address",
            "name": "token",
            "type": "address"
          },
          {
            "internalType": "uint256",
            "name": "identifier",
            "type": "uint256"
          },
          {
            "internalType": "uint256",
            "name": "amount",
            "type": "uint256"
          }
        ],
        "indexed": false,
        "internalType": "struct SpentItem[]",
        "name": "offer",
        "type": "tuple[]"
      },
      {
        "components": [
          {
            "internalType": "enum ItemType",
            "name": "itemType",
            "type": "uint8"
          },
          {
            "internalType": "address",
            "name": "token",
            "type": "address"
          },
          {
            "internalType": "uint256",
            "name": "identifier",
            "type": "uint256"
          },
          {
            "internalType": "uint256",
            "name": "amount",
            "type": "uint256"
          },
          {
            "internalType": "address payable",
            "name": "recipient",
            "type": "address"
          }
        ],
        "indexed": false,
        "internalType": "struct ReceivedItem[]",
        "name": "consideration",
        "type": "tuple[]"
      }
    ],
    "name": "OrderFulfilled",
    "type": "event"
  }
]
'''

# ----- Functions -----
def get_web3_instance():
    """Get a Web3 instance"""
    w3 = Web3(Web3.HTTPProvider(f"https://mainnet.infura.io/v3/{INFURA_KEY}"))
    
    if not w3.is_connected():
        raise ConnectionError("Cannot connect to Ethereum node!")
    
    print(f"Connected to Ethereum network (chainId: {w3.eth.chain_id})")
    return w3

def get_seaport_contract(w3):
    """Get Seaport contract instance"""
    return w3.eth.contract(address=SEAPORT_ADDRESS, abi=json.loads(SEAPORT_ABI))

def get_collection_name(token_address):
    """
    Get NFT collection name, try to fetch from API if unknown
    
    Parameters:
    token_address (str): NFT contract address
    
    Returns:
    str: Collection name
    """
    # Convert to lowercase to match dictionary keys
    address_lower = token_address.lower()
    
    # First check local mapping
    if address_lower in NFT_COLLECTIONS:
        return NFT_COLLECTIONS[address_lower]
    
    # If not in local mapping, try to use Etherscan API
    try:
        response = requests.get(
            f"https://api.etherscan.io/api?module=contract&action=getsourcecode&address={token_address}&apikey={ETHERSCAN_KEY}",
            timeout=5
        )
        data = response.json()
        if data["status"] == "1" and data["result"]:
            contract_name = data["result"][0].get("ContractName", "")
            if contract_name:
                # Add newly discovered collection to the mapping
                NFT_COLLECTIONS[address_lower] = contract_name
                return contract_name
    except Exception as e:
        print(f"Error getting contract name: {e}")
    
    # If unable to get the name, return the address
    return token_address

def get_item_type_name(item_type):
    """
    Convert item type ID to readable name
    
    Parameters:
    item_type (int): Item type ID
    
    Returns:
    str: Item type name
    """
    item_types = {
        0: "NATIVE",      # ETH
        1: "ERC20",       # ERC20 token
        2: "ERC721",      # NFT (ERC721)
        3: "ERC1155",     # Semi-fungible token (ERC1155)
        4: "ERC721_WITH_CRITERIA",
        5: "ERC1155_WITH_CRITERIA"
    }
    return item_types.get(item_type, f"UNKNOWN ({item_type})")

def fetch_nft_sales_graphql(first=100, skip=0):
    """Fetch NFT sales data from The Graph API"""
    query = """
    {
      orderFulfilleds(first: %d, skip: %d, orderBy: blockTimestamp, orderDirection: desc) {
        id
        offerer
        recipient
        zone
        orderHash
        offer
        consideration
        blockNumber
        transactionHash
        blockTimestamp
      }
    }
    """ % (first, skip)
    
    try:
        response = requests.post(
            API_ENDPOINT,
            json={"query": query},
            timeout=30  # Increase timeout
        )
        
        if response.status_code != 200:
            print(f"Request failed: {response.status_code}")
            print(response.text)
            return []
        
        data = response.json()
        
        if "errors" in data:
            print("Query error:")
            print(json.dumps(data["errors"], indent=2))
            return []
        
        return data.get("data", {}).get("orderFulfilleds", [])
    
    except Exception as e:
        print(f"Error during request: {e}")
        time.sleep(5)  # Wait after error
        return []

def parse_sale_data_graphql(sale):
    """Parse raw sale data from GraphQL"""
    try:
        # Extract basic information
        transaction_hash = sale.get("transactionHash", "")
        offerer = sale.get("offerer", "")  # Seller
        recipient = sale.get("recipient", "")  # Buyer
        zone = sale.get("zone", "")
        order_hash = sale.get("orderHash", "")
        block_timestamp = int(sale.get("blockTimestamp", "0"))
        block_number = int(sale.get("blockNumber", "0"))
        
        # Process time information
        date_time = datetime.fromtimestamp(block_timestamp)
        date_str = date_time.strftime('%Y-%m-%d')
        time_str = date_time.strftime('%H:%M:%S')
        day_of_week = date_time.weekday()  # 0=Monday, 6=Sunday
        weekday_names = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]
        day_name = weekday_names[day_of_week]
        hour = date_time.hour
        is_weekend = day_of_week >= 5  # 5=Saturday, 6=Sunday
        
        # Return processed record
        return {
            "transaction_hash": transaction_hash,
            "order_hash": order_hash,
            "seller": offerer,
            "buyer": recipient,
            "zone": zone,
            "timestamp": block_timestamp,
            "date": date_str,
            "time": time_str,
            "day_of_week": day_of_week,
            "day_name": day_name,
            "hour": hour,
            "is_weekend": is_weekend,
            "block_number": block_number,
        }
    
    except Exception as e:
        print(f"Error processing transaction data: {e}")
        return None

def decode_transaction_web3(tx_hash, w3, seaport_contract):
    """
    Decode transaction and extract NFT trade details
    
    Parameters:
    tx_hash (str): Transaction hash
    w3 (Web3): Web3 instance
    seaport_contract (Contract): Seaport contract instance
    
    Returns:
    dict: Decoded transaction data
    """
    try:
        # Get transaction information
        tx = w3.eth.get_transaction(tx_hash)
        receipt = w3.eth.get_transaction_receipt(tx_hash)
        block = w3.eth.get_block(receipt.blockNumber)
        
        # Extract basic transaction info
        transaction_info = {
            "hash": tx_hash,
            "from": tx["from"],
            "to": tx.to,
            "block_number": receipt.blockNumber,
            "timestamp": block.timestamp,
            "datetime": datetime.fromtimestamp(block.timestamp).strftime('%Y-%m-%d %H:%M:%S'),
            "gas_used": receipt.gasUsed,
            "gas_price": w3.from_wei(tx.gasPrice, 'gwei'),
            "tx_fee_eth": w3.from_wei(tx.gasPrice * receipt.gasUsed, 'ether'),
        }
        
        # Find OrderFulfilled events
        order_fulfilled_events = []
        
        for log in receipt.logs:
            # Check if log is from Seaport contract
            if log.address.lower() == seaport_contract.address.lower():
                try:
                    # Try to parse log as OrderFulfilled event
                    parsed_log = seaport_contract.events.OrderFulfilled().process_log(log)
                    order_fulfilled_events.append(parsed_log)
                except Exception as e:
                    # If parsing fails, this might not be an OrderFulfilled event
                    continue
        
        # If no OrderFulfilled events found, return basic info
        if not order_fulfilled_events:
            transaction_info["has_order_fulfilled"] = False
            return transaction_info
        
        # Process first OrderFulfilled event
        event_data = order_fulfilled_events[0].args
        transaction_info["has_order_fulfilled"] = True
        
        # Add basic event info
        transaction_info.update({
            "order_hash": event_data.orderHash.hex(),
            "offerer": event_data.offerer,        # Seller
            "zone": event_data.zone,
            "recipient": event_data.recipient,    # Buyer
        })
        
        # Process offer array (items offered by seller, usually NFTs)
        nft_items = []
        for item in event_data.offer:
            item_type = item.itemType
            item_info = {
                "item_type": item_type,
                "item_type_name": get_item_type_name(item_type),
                "token_address": item.token,
                "token_id": item.identifier,
                "amount": item.amount
            }
            
            # If it's an NFT, add more info
            if item_type in [2, 3, 4, 5]:  # ERC721 or ERC1155
                item_info["is_nft"] = True
                item_info["collection_name"] = get_collection_name(item.token)
                item_info["opensea_link"] = f"https://opensea.io/assets/{item.token}/{item.identifier}"
            else:
                item_info["is_nft"] = False
            
            nft_items.append(item_info)
        
        # Process consideration array (items received by seller, usually ETH or ERC20)
        payment_items = []
        total_eth_value = 0
        
        for item in event_data.consideration:
            item_type = item.itemType
            item_info = {
                "item_type": item_type,
                "item_type_name": get_item_type_name(item_type),
                "token_address": item.token,
                "token_id": item.identifier,
                "amount": item.amount,
                "recipient": item.recipient
            }
            
            # If it's ETH or ERC20, calculate value
            if item_type in [0, 1]:  # NATIVE or ERC20
                amount_eth = float(w3.from_wei(item.amount, 'ether'))
                item_info["amount_eth"] = amount_eth
                total_eth_value += amount_eth
            
            payment_items.append(item_info)
        
        # Add price info
        transaction_info["total_price_eth"] = total_eth_value
        
        # Determine primary NFT info (if any)
        primary_nft = None
        if nft_items:
            primary_nft = nft_items[0]
            transaction_info.update({
                "nft_token_address": primary_nft["token_address"],
                "nft_token_id": primary_nft["token_id"],
                "nft_collection": primary_nft.get("collection_name", "Unknown"),
                "nft_type": primary_nft["item_type_name"]
            })
        
        # Save detailed info
        transaction_info["nft_items"] = nft_items
        transaction_info["payment_items"] = payment_items
        
        return transaction_info
    
    except Exception as e:
        print(f"Error decoding transaction {tx_hash}: {e}")
        return {"hash": tx_hash, "error": str(e)}

def display_transaction_details(transaction_info):
    """
    Display transaction details in a friendly format
    
    Parameters:
    transaction_info (dict): Transaction information
    """
    print("\nTransaction Details:")
    print("="*60)
    print(f"Transaction Hash: {transaction_info['hash']}")
    print(f"Block Number: {transaction_info['block_number']}")
    print(f"Time: {transaction_info['datetime']}")
    print(f"From: {transaction_info['from']}")
    print(f"To: {transaction_info['to']}")
    print(f"Gas Used: {transaction_info['gas_used']}")
    print(f"Gas Price: {transaction_info['gas_price']} Gwei")
    print(f"Transaction Fee: {transaction_info['tx_fee_eth']} ETH")
    
    # If no OrderFulfilled events, show message and return
    if not transaction_info.get("has_order_fulfilled", False):
        print("\n⚠️ No NFT trade event found in this transaction")
        return
    
    print("\nNFT Trade Details:")
    print("-"*60)
    print(f"Seller: {transaction_info['offerer']}")
    print(f"Buyer: {transaction_info['recipient']}")
    
    # Display NFT info
    if "nft_items" in transaction_info and transaction_info["nft_items"]:
        print("\nNFTs Traded:")
        for i, item in enumerate(transaction_info["nft_items"], 1):
            print(f"  NFT {i}:")
            print(f"    Type: {item['item_type_name']}")
            print(f"    Collection: {item.get('collection_name', 'Unknown')}")
            print(f"    Contract Address: {item['token_address']}")
            print(f"    Token ID: {item['token_id']}")
            if "opensea_link" in item:
                print(f"    OpenSea Link: {item['opensea_link']}")
    
    # Display price info
    if "total_price_eth" in transaction_info:
        print(f"\nTrade Price: {transaction_info['total_price_eth']} ETH")
    
    if "payment_items" in transaction_info:
        print("\nPayment Details:")
        for i, item in enumerate(transaction_info["payment_items"], 1):
            print(f"  Payment {i}:")
            print(f"    Type: {item['item_type_name']}")
            if "amount_eth" in item:
                print(f"    Amount: {item['amount_eth']} ETH")
            print(f"    Recipient: {item['recipient']}")

def collect_nft_sales_from_graph(total_records=5000, batch_size=100, save_interval=1000):
    """
    Collect NFT sales data from The Graph
    
    Parameters:
    total_records (int): Total number of records to collect
    batch_size (int): Number of records to fetch per batch
    save_interval (int): How often to save progress
    
    Returns:
    pandas.DataFrame: Collected sales data
    """
    all_sales = []
    processed_count = 0
    error_count = 0
    max_errors = 5  # Maximum consecutive errors
    
    # Create progress bar
    progress_bar = tqdm(total=total_records, desc="Collecting NFT trade data")
    
    # If temp file exists, load previous progress
    temp_file = "temp_nft_transactions.csv"
    if os.path.exists(temp_file):
        print(f"Found temp file, loading previous progress...")
        temp_df = pd.read_csv(temp_file)
        all_sales = temp_df.to_dict('records')
        processed_count = len(all_sales)
        progress_bar.update(processed_count)
        print(f"Loaded {processed_count} records")
    
    try:
        for skip in range(processed_count, total_records, batch_size):
            try:
                # Get a batch of data
                batch = fetch_nft_sales_graphql(batch_size, skip)
                
                if not batch:
                    error_count += 1
                    if error_count >= max_errors:
                        print(f"Failed to get data {max_errors} times in a row, stopping")
                        break
                    continue
                
                error_count = 0  # Reset error count
                
                # Process this batch
                new_records = 0
                for sale in batch:
                    processed_sale = parse_sale_data_graphql(sale)
                    if processed_sale:
                        all_sales.append(processed_sale)
                        new_records += 1
                
                processed_count += new_records
                progress_bar.update(new_records)
                
                # Save progress periodically
                if processed_count % save_interval == 0 or processed_count >= total_records:
                    temp_sales_df = pd.DataFrame(all_sales)
                    temp_sales_df.to_csv(temp_file, index=False)
                    print(f"\nTemporarily saved {processed_count} records to {temp_file}")
                
                # Avoid frequent requests
                if skip + batch_size < total_records and batch:
                    time.sleep(1)  # Reduce wait time to improve efficiency
            
            except Exception as e:
                print(f"\nError during batch processing (skip={skip}): {e}")
                time.sleep(5)  # Wait longer after error
    
    finally:
        progress_bar.close()
    
    # Convert to DataFrame
    if all_sales:
        sales_df = pd.DataFrame(all_sales)
        return sales_df
    else:
        print("No NFT trade data found")
        return pd.DataFrame()

def analyze_nft_data(sales_df):
    """Analyze trade data and generate statistics and visualizations"""
    if sales_df.empty:
        print("No data available for analysis")
        return
    
    print("\nStarting trade data analysis...")
    
    # 1. Basic info
    print(f"Total transactions: {len(sales_df)}")
    print(f"Date range: {sales_df['date'].min()} to {sales_df['date'].max()}")
    print(f"Unique buyers: {sales_df['buyer'].nunique()}")
    print(f"Unique sellers: {sales_df['seller'].nunique()}")
    
    # 2. Time analysis
    # By hour
    hourly_stats = sales_df.groupby("hour").size()
    print("\nTransactions by hour:")
    print(hourly_stats)
    
    # By day of week
    weekday_stats = sales_df.groupby("day_name").size()
    print("\nTransactions by day of week:")
    print(weekday_stats)
    
    # 3. Address analysis
    # Most active buyers
    top_buyers = sales_df["buyer"].value_counts().head(10)
    print("\nTop 10 most active buyers:")
    print(top_buyers)
    
    # Most active sellers
    top_sellers = sales_df["seller"].value_counts().head(10)
    print("\nTop 10 most active sellers:")
    print(top_sellers)
    
    # 4. Create visualizations
    plt.figure(figsize=(15, 12))
    
    # Time distribution
    plt.subplot(2, 2, 1)
    sales_df.groupby("hour").size().plot(kind="bar")
    plt.title("NFT Transaction Distribution by Hour")
    plt.xlabel("Hour of Day")
    plt.ylabel("Number of Transactions")
    
    # Day of week distribution
    plt.subplot(2, 2, 2)
    # Sort by day of week
    day_order = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]
    weekday_counts = sales_df.groupby("day_name").size().reindex(day_order)
    weekday_counts.plot(kind="bar")
    plt.title("NFT Transaction Distribution by Day of Week")
    plt.xticks(rotation=45)
    plt.ylabel("Number of Transactions")
    
    # Date trend
    plt.subplot(2, 2, 3)
    sales_df["parsed_date"] = pd.to_datetime(sales_df["date"])
    daily_counts = sales_df.groupby(sales_df["parsed_date"].dt.date).size()
    daily_counts.plot()
    plt.title("Daily NFT Transaction Volume")
    plt.xlabel("Date")
    plt.ylabel("Number of Transactions")
    
    # Buyer-seller analysis
    plt.subplot(2, 2, 4)
    transactions_per_address = pd.DataFrame({
        "Buyers": sales_df["buyer"].value_counts().value_counts(),
        "Sellers": sales_df["seller"].value_counts().value_counts()
    })
    transactions_per_address.plot(kind="bar")
    plt.title("Transaction Count Distribution")
    plt.xlabel("Number of Transactions per Address")
    plt.ylabel("Number of Addresses")
    plt.yscale("log")
    
    plt.tight_layout()
    plt.savefig("nft_transaction_analysis.png")
    print("\nVisualizations saved to nft_transaction_analysis.png")
    
    return (hourly_stats, weekday_stats, top_buyers, top_sellers)

def prepare_data_for_llm(sales_df, sample_size=1000):
    """Prepare data sample for LLM analysis"""
    # Sort by time
    sales_df = sales_df.sort_values("timestamp", ascending=False)
    
    # Add transaction index
    sales_df["transaction_index"] = range(1, len(sales_df) + 1)
    
    # Select subset of sales data
    if len(sales_df) > sample_size:
        # Sampling strategy: prioritize recent transactions, then randomly sample the rest
        recent_records = min(sample_size // 2, len(sales_df))
        recent_df = sales_df.head(recent_records)
        older_df = sales_df.iloc[recent_records:].sample(sample_size - recent_records)
        llm_sales = pd.concat([recent_df, older_df])
    else:
        llm_sales = sales_df
    
    # Select important columns
    llm_sales = llm_sales[[
        'transaction_index', 'transaction_hash', 'seller', 'buyer', 
        'date', 'time', 'day_name', 'hour', 'is_weekend'
    ]]
    
    # Save as CSV for LLM analysis
    llm_sales.to_csv("llm_nft_transactions_sample.csv", index=False)
    print(f"Saved {len(llm_sales)} sample transactions to llm_nft_transactions_sample.csv (for LLM analysis)")
    
    # Prepare statistical summaries for LLM
    hourly_stats = sales_df.groupby("hour").size().reset_index(name="transactions")
    hourly_stats.to_csv("llm_hourly_stats.csv", index=False)
    
    weekday_stats = sales_df.groupby(["day_of_week", "day_name"]).size().reset_index(name="transactions")
    weekday_stats = weekday_stats.sort_values("day_of_week")
    weekday_stats.to_csv("llm_weekday_stats.csv", index=False)
    
    # Buyer analysis
    buyer_stats = sales_df.groupby("buyer").size().reset_index(name="transactions")
    buyer_stats = buyer_stats.sort_values("transactions", ascending=False)
    buyer_stats.head(100).to_csv("llm_top_buyers.csv", index=False)
    
    # Seller analysis
    seller_stats = sales_df.groupby("seller").size().reset_index(name="transactions")
    seller_stats = seller_stats.sort_values("transactions", ascending=False)
    seller_stats.head(100).to_csv("llm_top_sellers.csv", index=False)
    
    # Date statistics
    date_stats = sales_df.groupby("date").size().reset_index(name="transactions")
    date_stats["date"] = pd.to_datetime(date_stats["date"])
    date_stats = date_stats.sort_values("date")
    date_stats.to_csv("llm_daily_transactions.csv", index=False)
    
    print("All LLM analysis data prepared")

def enrich_graphql_data_with_web3(sales_df, max_transactions=100):
    """Enrich GraphQL data with detailed information using Web3"""
    print(f"\nEnriching the first {max_transactions} transactions with Web3 details...")
    
    # Initialize Web3 connection
    w3 = get_web3_instance()
    seaport_contract = get_seaport_contract(w3)
    
    # Take first N transactions for detailed parsing
    transactions_to_enrich = min(max_transactions, len(sales_df))
    enriched_data = []
    
    # Add progress bar
    for i, row in tqdm(sales_df.head(transactions_to_enrich).iterrows(), total=transactions_to_enrich, desc="Enriching transaction data"):
        tx_hash = row["transaction_hash"]
        try:
            # Decode transaction
            tx_info = decode_transaction_web3(tx_hash, w3, seaport_contract)
            if tx_info:
                # Add information from GraphQL
                tx_info.update({
                    "graphql_date": row.get("date", ""),
                    "graphql_time": row.get("time", ""),
                    "graphql_day_name": row.get("day_name", ""),
                    "graphql_hour": row.get("hour", ""),
                    "graphql_is_weekend": row.get("is_weekend", "")
                })
                enriched_data.append(tx_info)
        except Exception as e:
            print(f"Error processing transaction {tx_hash}: {e}")
    
    # Convert to DataFrame
    if enriched_data:
        enriched_df = pd.DataFrame(enriched_data)
        # Save enriched data
        enriched_df.to_csv("enriched_nft_transactions.csv", index=False)
        print(f"Saved {len(enriched_df)} enriched transactions to enriched_nft_transactions.csv")
        return enriched_df
    else:
        print("No enriched transaction data")
        return pd.DataFrame()

def analyze_top_sellers(sales_df, num_sellers=2, transactions_per_seller=5):
    """
    Analyze the top sellers by transaction count and fetch detailed information about their transactions
    
    Parameters:
    sales_df (DataFrame): DataFrame containing transaction data
    num_sellers (int): Number of top sellers to analyze
    transactions_per_seller (int): Number of transactions to analyze per seller
    
    Returns:
    dict: Analysis results for top sellers
    """
    print(f"\nAnalyzing top {num_sellers} sellers by transaction volume...")
    
    # Get top sellers by transaction count
    top_sellers = sales_df["seller"].value_counts().head(num_sellers)
    print("\nTop sellers by transaction volume:")
    for idx, (seller, count) in enumerate(top_sellers.items(), 1):
        print(f"{idx}. {seller}: {count} transactions")
    
    # Initialize Web3 connection
    w3 = get_web3_instance()
    seaport_contract = get_seaport_contract(w3)
    
    # Store results
    seller_analysis = {}
    
    # Analyze each seller
    for seller_address in top_sellers.index:
        print(f"\nAnalyzing seller: {seller_address}")
        
        # Get transactions for this seller
        seller_transactions = sales_df[sales_df["seller"] == seller_address].head(transactions_per_seller)
        
        # Store transaction details for this seller
        seller_info = {
            "address": seller_address,
            "total_transactions": int(top_sellers[seller_address]),  # Convert int64 to int
            "analyzed_transactions": len(seller_transactions),
            "transactions": []
        }
        
        # Get detailed information for each transaction
        for _, row in tqdm(seller_transactions.iterrows(), 
                          total=len(seller_transactions), 
                          desc=f"Getting transactions for seller {seller_address[:10]}..."):
            tx_hash = row["transaction_hash"]
            try:
                # Decode transaction
                tx_info = decode_transaction_web3(tx_hash, w3, seaport_contract)
                if tx_info and tx_info.get("has_order_fulfilled", False):
                    # Extract important transaction data
                    tx_summary = {
                        "hash": tx_hash,
                        "timestamp": int(tx_info.get("timestamp", 0)),  # Convert to int
                        "datetime": tx_info.get("datetime", ""),
                        "buyer": tx_info.get("recipient", ""),
                        "gas_used": int(tx_info.get("gas_used", 0)),  # Convert to int
                        "tx_fee_eth": float(tx_info.get("tx_fee_eth", 0)),  # Convert to float
                        "total_price_eth": float(tx_info.get("total_price_eth", 0))  # Convert to float
                    }
                    
                    # Extract NFT information
                    if "nft_items" in tx_info and tx_info["nft_items"]:
                        primary_nft = tx_info["nft_items"][0]
                        tx_summary.update({
                            "nft_collection": primary_nft.get("collection_name", "Unknown"),
                            "nft_token_id": str(primary_nft.get("token_id", "")),  # Convert to string
                            "nft_token_address": primary_nft.get("token_address", ""),
                            "nft_type": primary_nft.get("item_type_name", "")
                        })
                    
                    seller_info["transactions"].append(tx_summary)
                    
            except Exception as e:
                print(f"Error processing transaction {tx_hash} for seller {seller_address}: {e}")
        
        # Calculate statistics
        if seller_info["transactions"]:
            # Convert to DataFrame for analysis
            tx_df = pd.DataFrame(seller_info["transactions"])
            
            # Add statistics
            if "total_price_eth" in tx_df.columns:
                price_values = pd.to_numeric(tx_df["total_price_eth"], errors="coerce")
                seller_info["avg_price_eth"] = float(price_values.mean())  # Convert to float
                seller_info["max_price_eth"] = float(price_values.max())  # Convert to float
                seller_info["min_price_eth"] = float(price_values.min())  # Convert to float
                seller_info["total_volume_eth"] = float(price_values.sum())  # Convert to float
            
            # Calculate most frequently traded NFT collections
            if "nft_collection" in tx_df.columns:
                collection_counts = tx_df["nft_collection"].value_counts()
                # Convert to regular Python dict with int values
                seller_info["top_collections"] = {k: int(v) for k, v in collection_counts.to_dict().items()}
            
            # Calculate unique buyers count
            if "buyer" in tx_df.columns:
                seller_info["unique_buyers"] = int(tx_df["buyer"].nunique())  # Convert to int
                # Convert to regular Python dict with int values
                seller_info["top_buyers"] = {k: int(v) for k, v in tx_df["buyer"].value_counts().head(3).to_dict().items()}
            
            print(f"\nSeller {seller_address} analysis results:")
            if "avg_price_eth" in seller_info:
                print(f"  Average price: {seller_info['avg_price_eth']:.4f} ETH")
                print(f"  Total volume: {seller_info['total_volume_eth']:.4f} ETH")
            if "top_collections" in seller_info:
                print("  Top collections:")
                for coll, count in list(seller_info["top_collections"].items())[:3]:
                    print(f"    {coll}: {count} transactions")
            if "unique_buyers" in seller_info:
                print(f"  Unique buyers: {seller_info['unique_buyers']}")
        
        # Add this seller's analysis to results
        seller_analysis[seller_address] = seller_info
    
    # Save detailed analysis results to file
    with open("top_sellers_analysis.json", "w") as f:
        json.dump(seller_analysis, f, indent=2)
    print(f"\nSaved top seller analysis results to top_sellers_analysis.json")
    
    # Also save data as CSV format
    all_transactions = []
    for seller, info in seller_analysis.items():
        for tx in info["transactions"]:
            tx["seller"] = seller
            all_transactions.append(tx)
            
    if all_transactions:
        tx_df = pd.DataFrame(all_transactions)
        tx_df.to_csv("top_sellers_transactions.csv", index=False)
        print(f"Saved top seller transaction data to top_sellers_transactions.csv")
    
    return seller_analysis

def analyze_best_buyers(sales_df, num_buyers=2, transactions_per_buyer=5):
    """
    Analyze the best buyers by transaction count and fetch detailed information about their transactions
    
    Parameters:
    sales_df (DataFrame): DataFrame containing transaction data
    num_buyers (int): Number of top buyers to analyze
    transactions_per_buyer (int): Number of transactions to analyze per buyer
    
    Returns:
    dict: Analysis results for top buyers
    """
    print(f"\nAnalyzing top {num_buyers} buyers by transaction volume...")
    
    # Get top buyers by transaction count
    top_buyers = sales_df["buyer"].value_counts().head(num_buyers)
    print("\nTop buyers by transaction volume:")
    for idx, (buyer, count) in enumerate(top_buyers.items(), 1):
        print(f"{idx}. {buyer}: {count} transactions")
    
    # Initialize Web3 connection
    w3 = get_web3_instance()
    seaport_contract = get_seaport_contract(w3)
    
    # Store results
    buyer_analysis = {}
    
    # Analyze each buyer
    for buyer_address in top_buyers.index:
        print(f"\nAnalyzing buyer: {buyer_address}")
        
        # Get transactions for this buyer
        buyer_transactions = sales_df[sales_df["buyer"] == buyer_address].head(transactions_per_buyer)
        
        # Store transaction details for this buyer
        buyer_info = {
            "address": buyer_address,
            "total_transactions": int(top_buyers[buyer_address]),  # Convert int64 to int
            "analyzed_transactions": len(buyer_transactions),
            "transactions": []
        }
        
        # Get detailed information for each transaction
        for _, row in tqdm(buyer_transactions.iterrows(), 
                          total=len(buyer_transactions), 
                          desc=f"Getting transactions for buyer {buyer_address[:10]}..."):
            tx_hash = row["transaction_hash"]
            try:
                # Decode transaction
                tx_info = decode_transaction_web3(tx_hash, w3, seaport_contract)
                if tx_info and tx_info.get("has_order_fulfilled", False):
                    # Extract important transaction data
                    tx_summary = {
                        "hash": tx_hash,
                        "timestamp": int(tx_info.get("timestamp", 0)),  # Convert to int
                        "datetime": tx_info.get("datetime", ""),
                        "seller": tx_info.get("offerer", ""),
                        "gas_used": int(tx_info.get("gas_used", 0)),  # Convert to int
                        "tx_fee_eth": float(tx_info.get("tx_fee_eth", 0)),  # Convert to float
                        "total_price_eth": float(tx_info.get("total_price_eth", 0))  # Convert to float
                    }
                    
                    # Extract NFT information
                    if "nft_items" in tx_info and tx_info["nft_items"]:
                        primary_nft = tx_info["nft_items"][0]
                        tx_summary.update({
                            "nft_collection": primary_nft.get("collection_name", "Unknown"),
                            "nft_token_id": str(primary_nft.get("token_id", "")),  # Convert to string
                            "nft_token_address": primary_nft.get("token_address", ""),
                            "nft_type": primary_nft.get("item_type_name", "")
                        })
                    
                    buyer_info["transactions"].append(tx_summary)
                    
            except Exception as e:
                print(f"Error processing transaction {tx_hash} for buyer {buyer_address}: {e}")
        
        # Calculate statistics
        if buyer_info["transactions"]:
            # Convert to DataFrame for analysis
            tx_df = pd.DataFrame(buyer_info["transactions"])
            
            # Add statistics
            if "total_price_eth" in tx_df.columns:
                price_values = pd.to_numeric(tx_df["total_price_eth"], errors="coerce")
                buyer_info["avg_price_eth"] = float(price_values.mean())  # Convert to float
                buyer_info["max_price_eth"] = float(price_values.max())  # Convert to float
                buyer_info["min_price_eth"] = float(price_values.min())  # Convert to float
                buyer_info["total_spent_eth"] = float(price_values.sum())  # Convert to float
            
            # Calculate most frequently purchased NFT collections
            if "nft_collection" in tx_df.columns:
                collection_counts = tx_df["nft_collection"].value_counts()
                # Convert to regular Python dict with int values
                buyer_info["top_collections"] = {k: int(v) for k, v in collection_counts.to_dict().items()}
            
            # Calculate unique sellers count
            if "seller" in tx_df.columns:
                buyer_info["unique_sellers"] = int(tx_df["seller"].nunique())  # Convert to int
                # Convert to regular Python dict with int values
                buyer_info["top_sellers"] = {k: int(v) for k, v in tx_df["seller"].value_counts().head(3).to_dict().items()}
            
            print(f"\nBuyer {buyer_address} analysis results:")
            if "avg_price_eth" in buyer_info:
                print(f"  Average purchase price: {buyer_info['avg_price_eth']:.4f} ETH")
                print(f"  Total spent: {buyer_info['total_spent_eth']:.4f} ETH")
            if "top_collections" in buyer_info:
                print("  Top collections purchased:")
                for coll, count in list(buyer_info["top_collections"].items())[:3]:
                    print(f"    {coll}: {count} purchases")
            if "unique_sellers" in buyer_info:
                print(f"  Purchased from {buyer_info['unique_sellers']} unique sellers")
        
        # Add this buyer's analysis to results
        buyer_analysis[buyer_address] = buyer_info
    
    # Save detailed analysis results to file
    with open("top_buyers_analysis.json", "w") as f:
        json.dump(buyer_analysis, f, indent=2)
    print(f"\nSaved top buyer analysis results to top_buyers_analysis.json")
    
    # Also save data as CSV format
    all_transactions = []
    for buyer, info in buyer_analysis.items():
        for tx in info["transactions"]:
            tx["buyer"] = buyer
            all_transactions.append(tx)
            
    if all_transactions:
        tx_df = pd.DataFrame(all_transactions)
        tx_df.to_csv("top_buyers_transactions.csv", index=False)
        print(f"Saved top buyer transaction data to top_buyers_transactions.csv")
    
    return buyer_analysis

def main():
    """Main function - comprehensive data collection and analysis"""
    print("Welcome to the NFT Transaction Analysis Tool!")
    print("="*60)
    
    # Choose execution mode
    print("\nPlease select operation mode:")
    print("1. Collect NFT transaction data using GraphQL API (batch)")
    print("2. Parse NFT transactions directly using Web3 (single or few)")
    print("3. Combined mode: collect data with GraphQL, then enrich some transactions with Web3")
    
    try:
        mode = int(input("\nEnter your choice (1/2/3): "))
    except ValueError:
        print("Invalid input, defaulting to mode 3")
        mode = 3
    
    # Mode 1: Collect data using GraphQL
    if mode == 1:
        print("\nStarting NFT transaction data collection using GraphQL...")
        try:
            total_records = int(input("Enter number of transactions to collect (default 5000): ") or "5000")
            batch_size = int(input("Enter batch size (default 100): ") or "100")
        except ValueError:
            print("Invalid input, using default values")
            total_records = 5000
            batch_size = 100
        
        # Collect data
        sales_df = collect_nft_sales_from_graph(total_records=total_records, batch_size=batch_size)
        
        if sales_df.empty:
            print("No NFT transaction data found, exiting")
            return
        
        # Save raw data
        sales_df.to_csv("nft_transactions.csv", index=False)
        print(f"Saved {len(sales_df)} NFT transaction records to nft_transactions.csv")
        
        # Analyze data
        analyze_nft_data(sales_df)
        
        # Prepare LLM analysis data
        prepare_data_for_llm(sales_df)
    
    # Mode 2: Parse transactions directly using Web3
    elif mode == 2:
        print("\nStarting direct NFT transaction parsing using Web3...")
        
        # Get transaction hash(es)
        tx_input = input("Enter transaction hash(es) (comma separated): ")
        tx_hashes = [tx.strip() for tx in tx_input.split(',')]
        
        if not tx_hashes or not tx_hashes[0]:
            print("No transaction hashes provided, using example hash...")
            tx_hashes = ["0xa9dfe4c8ddd3f263af79278866586a244b534eaf83e9b3e2aa830f3aabbaeebf"]
        
        # Initialize Web3
        w3 = get_web3_instance()
        seaport_contract = get_seaport_contract(w3)
        
        # Process each transaction hash
        all_transactions = []
        for i, tx_hash in enumerate(tx_hashes, 1):
            print(f"[{i}/{len(tx_hashes)}] Processing transaction: {tx_hash}")
            
            # Decode transaction
            tx_info = decode_transaction_web3(tx_hash, w3, seaport_contract)
            
            # Display details
            display_transaction_details(tx_info)
            
            # Add to results list
            all_transactions.append(tx_info)
        
        # Create DataFrame
        df = pd.DataFrame([{
            "hash": tx.get("hash", ""),
            "block_number": tx.get("block_number", ""),
            "timestamp": tx.get("timestamp", ""),
            "datetime": tx.get("datetime", ""),
            "from_address": tx.get("from", ""),
            "to_address": tx.get("to", ""),
            "gas_used": tx.get("gas_used", ""),
            "gas_price_gwei": tx.get("gas_price", ""),
            "tx_fee_eth": tx.get("tx_fee_eth", ""),
            "has_nft_trade": tx.get("has_order_fulfilled", False),
            "seller": tx.get("offerer", ""),
            "buyer": tx.get("recipient", ""),
            "price_eth": tx.get("total_price_eth", ""),
            "nft_token_address": tx.get("nft_token_address", ""),
            "nft_token_id": tx.get("nft_token_id", ""),
            "nft_collection": tx.get("nft_collection", ""),
            "nft_type": tx.get("nft_type", ""),
            "error": tx.get("error", "")
        } for tx in all_transactions])
        
        # Save to CSV
        df.to_csv("nft_transactions.csv", index=False)
        print(f"Data saved to nft_transactions.csv")
        
        # Show statistics
        print("\nData Analysis:")
        print(f"Total transactions: {len(df)}")
        nft_trades = df[df["has_nft_trade"] == True]
        print(f"NFT trade count: {len(nft_trades)}")
        
        if not nft_trades.empty:
            if 'price_eth' in nft_trades.columns:
                price_eth_series = pd.to_numeric(nft_trades['price_eth'], errors='coerce')
                print(f"Average price: {price_eth_series.mean():.4f} ETH")
                print(f"Maximum price: {price_eth_series.max():.4f} ETH")
            
            # Collection statistics
            print("\nCollection Statistics:")
            if 'nft_collection' in nft_trades.columns:
                collection_counts = nft_trades['nft_collection'].value_counts()
                for coll, count in collection_counts.items():
                    print(f"  {coll}: {count} transactions")
    
    # Mode 3: Combined mode
    else:
        print("\nStarting combined mode...")
        
        # 1. First collect data using GraphQL
        print("\nStep 1: Collecting NFT transaction data using GraphQL...")
        try:
            total_records = int(input("Enter number of transactions to collect (default 2000): ") or "2000")
            batch_size = int(input("Enter batch size (default 100): ") or "100")
        except ValueError:
            print("Invalid input, using default values")
            total_records = 2000
            batch_size = 100
        
        # Collect data
        sales_df = collect_nft_sales_from_graph(total_records=total_records, batch_size=batch_size)
        
        if sales_df.empty:
            print("No NFT transaction data found, exiting")
            return
        
        # Save raw data
        sales_df.to_csv("nft_transactions_graphql.csv", index=False)
        print(f"Saved {len(sales_df)} NFT transactions from GraphQL to nft_transactions_graphql.csv")
        
        # 2. Enrich some transactions with Web3
        print("\nStep 2: Enriching some transactions with detailed information using Web3...")
        try:
            max_enrich = int(input("Enter number of transactions to enrich (default 20): ") or "20")
        except ValueError:
            print("Invalid input, using default value")
            max_enrich = 20
        
        # Enrich data
        enriched_df = enrich_graphql_data_with_web3(sales_df, max_transactions=max_enrich)
        
        # 3. Analyze data
        print("\nStep 3: Analyzing data...")
        analyze_nft_data(sales_df)
        
        # 4. Prepare LLM analysis data
        print("\nStep 4: Preparing data for LLM analysis...")
        prepare_data_for_llm(sales_df)
        
        # 5. Analyze top sellers
        print("\nStep 5: Analyzing top sellers...")
        try:
            num_sellers = int(input("Enter number of top sellers to analyze (default 2): ") or "2")
            txs_per_seller = int(input("Enter number of transactions to analyze per seller (default 5): ") or "5")
        except ValueError:
            print("Invalid input, using default values")
            num_sellers = 2
            txs_per_seller = 5
            
        # Analyze top sellers
        seller_analysis = analyze_top_sellers(sales_df, num_sellers=num_sellers, transactions_per_seller=txs_per_seller)
        
        # 6. Analyze best buyers
        print("\nStep 6: Analyzing top buyers...")
        try:
            num_buyers = int(input("Enter number of top buyers to analyze (default 2): ") or "2")
            txs_per_buyer = int(input("Enter number of transactions to analyze per buyer (default 5): ") or "5")
        except ValueError:
            print("Invalid input, using default values")
            num_buyers = 2
            txs_per_buyer = 5
            
        # Analyze top buyers
        buyer_analysis = analyze_best_buyers(sales_df, num_buyers=num_buyers, transactions_per_buyer=txs_per_buyer)
        
        # Optional: Use LLM to analyze market data
        print("\nYou can provide the analysis JSON and CSV files to an LLM for further analysis")
    
    print("\nData processing complete!")
    
    # Delete temporary files
    if os.path.exists("temp_nft_transactions.csv"):
        os.remove("temp_nft_transactions.csv")
        print("Temporary files deleted")

if __name__ == "__main__":
    main()